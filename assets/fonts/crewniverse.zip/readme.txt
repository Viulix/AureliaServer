﻿Crewniverse Font V.5

Crewniverse is a font that replicates the one used for the title cards of the TV show Steven Universe(tm), as well as the logo of the Steven Crewniverse's Tumblr (hence the name, originally).

2015-2016 - Font by MaxiGamer - maxigamer.deviantart.com
Made in FontForge.

Steven Universe(tm) was created by Rebecca Sugar and is a trademark of Cartoon Network.

There is an extensive list of every character called "font_extensive.png".

-------------------------------------------------------------------------------------------
Changelog for V.5 (2016-8-19)
- Added a whoooole metric ton of accents;
- Added some more punctuation ( @ # % & () <> [] {} «» );
- Added some legal symbols or what not ( © ® ™ );
- Added a sharp S ( ß );
- Fixed a thing with P and R that I had never noticed before;
- Added some other stuff.
Goals for V.6 (?)
- To be frank, I think V.5 is gonna be the final version. We'll have to see! I might add Japanese and Greek symbols in the far future if I'm brave enough, but don't quote me on this. :^)

Changelog for V.4 (2016-6-04)
- FINALLY properly kerned the font;
- Added accents;
- Added inverted question and exclamation marks ( ¿ ¡ );
- Added quotation marks ( " );
- Added a few other things ( ` ´ ^ ¨ ~ _ ).
Goals for V.5 (or maybe V4.5)
- Add err I dunno, I'll see when I get there ¯\_(ツ)_/¯
  To be honest, I think the font is pretty much done, but y'know there's always room for improvement.

Changelog for V.3 (2016-1-12)
- FINALLY added numbers;
- Added a hyphen ( - ).
Goals for V.4:
- Add quotation marks;
- Add accents.

Changelog for V.2 (2015-6-25)
- Added exclamation and question marks;
- Updated every other punctuation.
Goals for V.3 or V.4
- Add quotation marks;
- Add numbers (at least 2 and 3);
- Add accents;
- Add various special characters.

Changelog for V.1 (2015-6-13)
- Font was created;
- Added letters + some punctuation.
Goals for V.2
- Add exclamation and question marks;
- Add quotation marks;
- Possibly add numbers (at least 2 and 3);
- Possibly add accents on letters A, E, I, O, U and C;
- Might add some other special characters.